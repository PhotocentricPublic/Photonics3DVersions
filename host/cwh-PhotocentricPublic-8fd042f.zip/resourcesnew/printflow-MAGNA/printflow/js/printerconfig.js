var printerName = "Photocentric Magna";
var repo = "PhotocentricPublic/Photonics3DVersions";
